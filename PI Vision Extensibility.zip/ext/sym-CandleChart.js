(function (PV) {
	"use strict";
		
	function symbolVis(){ };
	PV.deriveVisualizationFromBase(symbolVis);
	
	var definition = {
		typeName: "CandleChart",
		displayName: "Stock Bar Chart",
		visObjectType: symbolVis,
		datasourceBehavior: PV.Extensibility.Enums.DatasourceBehaviors.Multiple,
		iconUrl: "Scripts/app/editor/symbols/ext/images/presentation.svg",
		
		getDefaultConfig: function(){
			return {
				DataShape: "Timeseries",
				Height: 350,
				Width: 500,
				BorderRadius: 10,
			}
		},
		configOptions: function(){
			return[
				{
					title: "Format Symbol",
					mode: "format"
				}
			];
		}
	}
	
	function getConfig(){
		return {
			"type": "serial",
			"backgroundColor": "#FFFFFF",
			"color": "#000000",
			"fontFamily": "Arial",
			"fontSize": 12,
			"zoomOutOnDataUpdate": true,
			"mouseWheelScrollEnabled": false,
			"mouseWheelZoomEnabled": true,
			"zoomOutText": "Zoom Out",
			"zoomOutButtonPadding": 15,
			"zoomOutButtonImage": "lens",
			"zoomOutButtonColor": "#e5e5e5",
			"zoomOutButtonImageSize": 24,
			//"zoomOutButtonTabIndex": 40,
			"categoryField": "cdate",
			"startDuration": 1,
			//"dataDateFormat": "MM/DD/YYYY JJ:NN:SS",
			//"theme": "chalk",
			"theme": "default",
			"pathToImages": "Scripts/app/editor/symbols/ext/images/",
			"autoDisplay": false,
			"autoResize": true,
			"export": {
				"enabled": true,
			},
			"categoryAxis": {
				"gridPosition": "middle",
				"parseDates": true,
				"minorGridEnabled": true,
				"autoRotateAngle": 45,
				"axisColor": "#a7b4c1",
				"axisThickness": 1,
				"tickLength": 6,
				"gridColor": "#000000",
			},
			"chartCursor": {
				"enabled": true,
				"cursorPosition": "middle",
				"valueLineBalloonEnabled": true,
				"valueLineEnabled": true,
				"cursorColor": "#0077FF",
			},
			"chartScrollbar": {
				"enabled": true,
				"autoGridCount": false,
				"dragIcon": "dragIconRoundBig",
				"graph": "g1",
				"graphType": "smoothedLine",
				"oppositeAxis": false,
				"offset": 25,
				"scrollbarHeight": 30
			},
			"trendLines": [],
			"graphs": [
				{
					"balloonText": "Open:<b>[[open]]</b><br>Low:<b>[[low]]</b><br>High:<b>[[high]]</b><br>Close:<b>[[close]]</b><br>",
					"closeField": "cclose",
					"fillColors": "#7f8da9",
					"highField": "chigh",
					"id": "g1",
					"lineColor": "#7f8da9",
					"lowField": "clow",
					"negativeLineColor": "#db4c3c",
					"openField": "copen",
					"title": "Price:",
					"type": "ohlc",
					"valueField": "cclose"
				}
			],
			"guides": [],
			"valueAxes": [
				{
					"id": "ValueAxis-1",
					"gridColor": "#000000",
					"axisColor": "#a7b4c1",
					"axisThickness": 1,
					"tickLength": 6,
				}
			],
			"allLabels": [],
			"balloon": {
				"showBullet": true,
				"fixedPosition": false,
			},
			"titles": [
				{
					"color": "#000000",
					"id": "Title-1",
					"size": 30,
					"text": "Bar Chart"
				}
			],
			"dataProvider": [
				{
					"cdate": "11/14/2018 12:00:00 AM",
					"copen": "136.65",
					"chigh": "136.96",
					"clow": "134.15",
					"cclose": "136.49"
				},
				{
					"cdate": "11/15/2018 12:00:00 PM",
					"copen": "135.26",
					"chigh": "135.95",
					"clow": "131.50",
					"cclose": "131.85"
				},
				{
					"cdate": "11/16/2018 12:00:00 AM",
					"copen": "126.68",
					"chigh": "129.78",
					"clow": "125.63",
					"cclose": "129.40"
				}
			]
					
		}
	}
	
	symbolVis.prototype.init = function(scope, elem) {
		this.onDataUpdate = dataUpdate;
		this.onConfigChange = configChanged;
		
		scope.config.ZoomOutUpdate=false;
		scope.config.WheelZoom=true;
		// scope.config.Export=false;
		scope.config.Balloon=true;
		scope.config.Minor=true;
		scope.config.Cursor=true;
		scope.config.ValueLine=true;
		scope.config.ChartScrollbar=true;
		scope.config.ChartScrollbarAxis=false;	
		scope.config.AxisColor="#a7b4c1";
		scope.config.GridColor="#000000";
		scope.config.CursorColor="#0077FF";
		scope.config.LineColor="#7f8da9";
		scope.config.NegativeLineColor="#db4c3c";
		scope.config.FillColor="#7f8da9";
		scope.config.BackgroundColor="#FFFFFF";
		scope.config.FontColor="#000000";
		scope.config.FontSize=12;
		scope.config.AxisThickness=1;
		scope.config.TickLength=6;
		scope.config.ScrollbarHeight=30;
		scope.config.ScrollbarOffset=25;
		scope.config.ZOPadding=15;
		scope.config.FontFamily="Arial";
		scope.config.CursorPosition="middle";
		scope.config.Label=true;
	
		var updates = 0;
		var labels;
		var info;
		var valopen;
		var valclose;
		var valhigh;
		var vallow;
		
		var symbolContainerDiv = elem.find('#g1')[0];
		symbolContainerDiv.id = "g1_" + scope.symbol.Name;
		var chart = AmCharts.makeChart(symbolContainerDiv.id, getConfig());

		//chart.pathToImages = "ext/libraries/images/";
		//chart.dateFormatter.inputDateFormat = "M/d/yyyy h:m:s a"
		
		// AmCharts.formatDate(new Date(2014,1,3), "DD MMM, YYYY");
		// AmCharts.stringToDate("01-10-2014", "DD-MM-YYYY");
		
		function convertToChart (j){
			var dataProv=[];	
				dataProv = {
					cdate: valopen[j].Time,
					copen: valopen[j].Value,
					cclose: valclose[j].Value,
					chigh: valhigh[j].Value,
					clow: vallow[j].Value
				};
				
			return dataProv ;
			
		}
		

		function updateLabel(data){
			labels = data.Data.map(function(item){
				return item.Label;
			});
			
		}
		
		function updateInfo(data){
			info = data.Data.map(function(item){
				return item.Values;
			});
		}
		
		function dataUpdate(data){
			if( !data) return;
			if( data.Data[0].Label){
				updateLabel(data);
			}
			updateInfo(data);
			if( !labels || !chart) return;
			
			if(scope.config.Label==true){
				var separator = labels[0].indexOf("|");
				var title_x = labels[0].slice(0, separator);
				scope.config.Title=title_x;
			}
	
			//identifying open and close values
			var i;
			var len2 = labels.length;
			for (i=0; i<len2; i++){	
				if(labels[i].search("Open") != -1 || labels[i].search("open") != -1){
					valopen = info[i];
				} else if (labels[i].search("Close") != -1 || labels[i].search("close") != -1 || labels[i].search("CLOSE") != -1){
					valclose = info[i];
				} else if (labels[i].search("High") != -1 || labels[i].search("high") != -1 || labels[i].search("HIGH") != -1){
					valhigh = info[i];
				} else if (labels[i].search("Low") != -1 || labels[i].search("low") != -1 || labels[i].search("LOW") != -1){
					vallow = info[i];
				} else {
					console.log("Tag undefined");
				}	
			}
				
			info[0] = vallow;
			info[1] = valopen;
			info[2] = valclose;
			info[3] = valhigh;
			
			// console.log(data);	
			// console.log(info);	
			// console.log(labels);
			// console.log(valopen);
			// console.log(valclose);
			// console.log(scope.config.ShowUOM);
			
			var j;
			var dataprovider = [];
			var len = info[0].length;
			
			for(j=0; j<len; j++){
				dataprovider.push(convertToChart(j));
			}
			
			chart.dataProvider = dataprovider;
			chart.validateData();
			updates++;
		}
		
		function configChanged(data) {  
		//console.log(data);			
			// Color			
			// Axis Color
			chart.categoryAxis.axisColor = scope.config.AxisColor;
			chart.valueAxes[0].axisColor = scope.config.AxisColor;
			
			// Grid Color
			chart.categoryAxis.gridColor = scope.config.GridColor;
			chart.valueAxes[0].gridColor = scope.config.GridColor;
					
			// Cursor Color
			chart.chartCursor.cursorColor = scope.config.CursorColor;
			
			// Line Color
			chart.graphs[0].lineColor = scope.config.LineColor;
			
			// Negative Line Color
			chart.graphs[0].negativeLineColor = scope.config.NegativeLineColor;
			
			// Fill Color
			chart.graphs[0].fillColors = scope.config.FillColor;
					
			// Font Color
			chart.color = scope.config.FontColor;
			chart.titles[0].color = scope.config.FontColor;
			
			// Data
			// Font Size
			chart.fontSize = scope.config.FontSize;
			chart.titles[0].size = (scope.config.FontSize+18);
			
			// Axis Thickness
			chart.categoryAxis.axisThickness = scope.config.AxisThickness;
			chart.valueAxes[0].axisThickness = scope.config.AxisThickness;
			
			// Tick Length
			chart.categoryAxis.tickLength = scope.config.TickLength;
			chart.valueAxes[0].tickLength = scope.config.TickLength;
			
			// Scrollbar Height
			chart.chartScrollbar.scrollbarHeight = scope.config.ScrollbarHeight;
			
			// Scrollbar Offset
			chart.chartScrollbar.offset = scope.config.ScrollbarOffset;
			
			// ZoomOut Padding
			chart.zoomOutButtonPadding = scope.config.ZOPadding;
			
			// Label
			// Chart Title
			chart.titles[0].text = scope.config.Title;
			
			// Font Family
			chart.fontFamily = scope.config.FontFamily;
			
			// Cursor Position
			chart.chartCursor.cursorPosition = scope.config.CursorPosition;
			
			// Check Box	
			// Zoom Out
			if(scope.config.ZoomOutUpdate){
				chart.zoomOutOnDataUpdate=true;
			} else if (scope.config.ZoomOutUpdate==false){
				chart.zoomOutOnDataUpdate=false;
			}	

			// Mouse Wheel
			if(scope.config.WheelZoom){
				chart.mouseWheelZoomEnabled=true;
			} else if (scope.config.WheelZoom==false){
				chart.mouseWheelZoomEnabled=false;
			}

			// Export
			// if(scope.config.Export){
				// chart.export.enabled=true;
			// } else if (scope.config.Export==false){
				// chart.export.enabled=false;
			// }
			
			// Balloon
			if(scope.config.Balloon){
				chart.balloon.showBullet=true;
			} else if (scope.config.Balloon==false){
				chart.balloon.showBullet=false;
			}
			
			// Minor Grid
			if(scope.config.Minor){
				chart.categoryAxis.minorGridEnabled=true;
			} else if (scope.config.Minor==false){
				chart.categoryAxis.minorGridEnabled=false;
			}
			
			// Chart Cursor
			if(scope.config.Cursor){
				chart.chartCursor.enabled=true;
			} else if (scope.config.Cursor==false){
				chart.chartCursor.enabled=false;
			}
			
			// Value Line
			if(scope.config.ValueLine){
				chart.chartCursor.enabled=true;
				chart.chartCursor.valueLineEnabled=true;
			} else if (scope.config.ValueLine==false){
				chart.chartCursor.valueLineEnabled=false;
			}
			
			// Chart Scrollbar
			if(scope.config.ChartScrollbar){
				chart.chartScrollbar.enabled=true;
			} else if (scope.config.ChartScrollbar==false){
				chart.chartScrollbar.enabled=false;
			}
			
			// Chart Scrollbar Axis
			if(scope.config.ChartScrollbarAxis){
				chart.chartScrollbar.oppositeAxis=true;
			} else if (scope.config.ChartScrollbarAxis==false){
				chart.chartScrollbar.oppositeAxis=false;
			}
		}
	}; 
	
	PV.symbolCatalog.register(definition);
})(window.PIVisualization);