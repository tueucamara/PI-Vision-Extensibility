(function (PV) {
	"use strict";

	function symbolVis() { };
	PV.deriveVisualizationFromBase(symbolVis);
	
	/*var dataItem = {
		Time: "14-Mar-15 00:00:00",
		Value: 100
	};
	*/
	
	var definition = { 
		typeName: "basicvalue",
		visObjectType: symbolVis,
		datasourceBehavior: PV.Extensibility.Enums.DatasourceBehaviors.Single,
		iconUrl: "Images/news/goal.svg",
		getDefaultConfig: function(){ 
			return { 
				Height: 150,
				Width: 150 
			} 
		}
	}

	symbolVis.prototype.init = function(scope, elem) { 
		/*scope.Time = dataItem.Time;
		scope.Value = dataItem.Value;
		*/
		this.onDataUpdate = dataUpdate;
		
		function dataUpdate(newdata){
			if(newdata.Label){
				//sporadic
				
				scope.Label = newdata.Label;
				scope.Units = newdata.Units;
				scope.Path = newdata.Path.slice(0,2);
			}
					
			scope.Time = newdata.Time;
			scope.Value = newdata.Value;
		}
	};

	PV.symbolCatalog.register(definition); 
})(window.PIVisualization); 
