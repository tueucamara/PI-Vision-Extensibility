(function (PV) {
	"use strict";
		
	function symbolVis(){ };
	PV.deriveVisualizationFromBase(symbolVis);
	
	var dataItems = [
		{
			Time: "14-Mar-15 00:00:00",
			Value: 100
		},
		{
			Time: "4-Mar-15 00:00:00",
			Value: 50
		}
	];
	
	var definition = {
		typeName: "archivedata",
		visObjectType: symbolVis,
		datasourceBehavior: PV.Extensibility.Enums.DatasourceBehaviors.Multiple,
		iconUrl: "Images/news/presentation.svg",
		
		getDefaultConfig: function(){
			return {
				DataShape: 'Timeseries',
				Height: 150,
				Width: 150,
				BackgroundColor: "#ff5733",
				BorderRadius: 10,
				DisplayDigits: 2
			}
		},
		configOptions: function(){
			return[
				{
					title: "Format Symbol",
					mode: "format"
				}
			];
		}
	}
	
	symbolVis.prototype.init = function(scope, elem) {
		this.onDataUpdate = dataUpdate;
		this.onConfigChange = configChanged;
		
		function dataUpdate(data){
			if(!data) return;
			var firstAttribute = data.Data[0];
			scope.Values = firstAttribute.Values;
			scope.Length = firstAttribute.Values.length;
			
			if(firstAttribute.Label){
				scope.Units = firstAttribute.Units;
				scope.Label = firstAttribute.Label;
			}
		}
		
		function configChanged(newConfig, oldConfig) {  
			console.log(newConfig);
			console.log(oldConfig);
		} 
	}; 
	
	PV.symbolCatalog.register(definition);
})(window.PIVisualization);