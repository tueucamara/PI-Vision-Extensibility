(function (PV) {
	"use strict";
	
	function symbolVis(){ };
	PV.deriveVisualizationFromBase(symbolVis);
	
	var dataItems = [
		{
			Time: "14-Mar-15 00:00:00",
			Value: 100
		},
		{
			Time: "4-Mar-15 00:00:00",
			Value: 50
		}
	];
	
	var definition = {
		typeName: "timeSeries",
		visObjectType: symbolVis,
		datasourceBehavior: PV.Extensibility.Enums.DatasourceBehaviors.Multiple,
		iconUrl: "Images/news/flame.svg",
		getDefaultConfig: function(){
			return {
				DataShape: 'Timeseries',
				Height: 150,
				Width: 150
			}
		}
	}
	
	symbolVis.prototype.init = function(scope, elem) {
		this.onDataUpdate = dataUpdate;
		function dataUpdate(data){
			if(!data) return;
			console.log(data);
			var firstAttribute = data.Data[0];
			scope.Values = firstAttribute.Values;
			
			if(firstAttribute.Label){
				scope.Units = firstAttribute.Units;
				scope.Label = firstAttribute.Label;
			}
		}
	}; 
	
	PV.symbolCatalog.register(definition);
})(window.PIVisualization);