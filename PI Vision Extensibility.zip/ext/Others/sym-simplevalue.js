(function (PV) {
	"use strict";
	
	function symbolVis(){ };
	PV.deriveVisualizationFromBase(symbolVis);
	
	var definition = {
		typeName: "simplevalue",
		visObjectType: symbolVis,
		datasourceBehavior: PV.Extensibility.Enums.DatasourceBehaviors.Single,
		iconUrl: "Images/news/JoaoDasNeves.svg",
		getDefaultConfig: function(){
			return {
				Height: 150,
				Width: 150
			}
		}
	}
	
	symbolVis.prototype.init = function(scope, elem) {
		this.onDataUpdate = dataUpdate;
		
		function dataUpdate(data){
			if(data.Label){
				//sporadic
				scope.Label = data.Label;
				scope.Units = data.Units;
			}
			
			
			scope.Time = data.Time;
			scope.Value = data.Value;
		}
	}; 
	
	PV.symbolCatalog.register(definition);
})(window.PIVisualization);