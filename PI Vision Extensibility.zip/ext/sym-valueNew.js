(function (PV) {
	"use strict";

	function symbolVis() { };
	PV.deriveVisualizationFromBase(symbolVis);
	
	var definition = { 
		typeName: "valueNew",
		displayName: "Value Project",
		visObjectType: symbolVis,
		datasourceBehavior: PV.Extensibility.Enums.DatasourceBehaviors.Single,
		iconUrl: "Images/news/goal.svg",
		
		getDefaultConfig: function(){ 
			return { 
				FormatType: 'Database', //Scientific, Number, General / percent
				//DataShape: 'Value',
				Height: 150,
				Width: 350, 
				BackgroundColor: "#ff5733",
				BorderRadius: 10,
				DisplayDigits: 2,
				FormatOptions: {
					TextColor: 'rbg(0,123,127)',
					LineWidth: 12             
				}
			} 
		},
		configOptions: function(){
			return[
				{
					title: "Format Symbol",
					mode: "format"
				}
			];
		}
	}

	symbolVis.prototype.init = function(scope, elem) { 
		this.onDataUpdate = dataUpdate;
		
		scope.config.FormatType="Database";
		scope.config.FontSize=18;
		scope.config.FontColor="#000000";
		scope.config.BackgroundColor="rgba(0,0,0,0)"
		
		function dataUpdate(data){
			if(!data) return;
			if(data.Label){
				scope.Label = data.Label;
				scope.Units = data.Units;
			}			
			scope.Time = data.Time;
			scope.Value = data.Value;
		}
	};
	
	PV.symbolCatalog.register(definition); 
})(window.PIVisualization); 
